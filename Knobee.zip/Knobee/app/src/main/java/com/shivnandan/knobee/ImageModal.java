package com.shivnandan.knobee;

public class ImageModal {

    private String courseimg;

    // creating constructor for our variables.
    public ImageModal(String courseimg) {

        this.courseimg = courseimg;

    }


    public String getCourseimg() {
        return courseimg;
    }

    public void setCourseimg(String courseimg) {
        this.courseimg = courseimg;
    }

}

